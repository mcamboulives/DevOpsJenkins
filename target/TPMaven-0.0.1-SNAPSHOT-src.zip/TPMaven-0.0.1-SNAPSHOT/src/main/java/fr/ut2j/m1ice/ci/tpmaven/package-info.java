/** Info about this package doing something for package-info.java file.
 */
package fr.ut2j.m1ice.ci.tpmaven;

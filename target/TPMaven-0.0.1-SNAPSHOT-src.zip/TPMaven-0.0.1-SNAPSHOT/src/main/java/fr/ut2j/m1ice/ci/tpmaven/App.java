package fr.ut2j.m1ice.ci.tpmaven;

/**
 * Hello world!
 *
 */
public final class App {
    /** Create app main.
    * @param args arguments list.
    */
    public static void main(final String[] args) {
        System.out.println("Hello World!");
    }
}
